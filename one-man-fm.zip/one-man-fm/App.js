import React from 'react';
import {
  View,
  StyleSheet,
  Text,
} from 'react-native';
import { MaterialIcons } from '@expo/vector-icons';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { NavigationContainer } from '@react-navigation/native';
import { WebView } from 'react-native-webview';

const Tab = createBottomTabNavigator();

// --- 1. LIVE PLAYER HTML ---
const mainLiveHTML = `
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<style>
  body { margin: 0; padding: 10px; background: #000; font-family: 'Arial Black', sans-serif; display: flex; flex-direction: column; align-items: center; gap: 15px; }
  .main-container { background: #1a1a1a; width: 100%; max-width: 320px; padding: 15px; border-radius: 20px; text-align: center; border: 6px solid #ffffff; box-sizing: border-box; }
  .status-bar-red { background: #1a1a1a; padding: 6px; border-radius: 10px; margin-bottom: 10px; font-size: 12px; letter-spacing: 2px; font-weight: bold; display: flex; align-items: center; justify-content: center; gap: 8px; border: 3px solid #ff0000; }
  .status-dot-red { width: 10px; height: 10px; background: #ff0000; border-radius: 50%; box-shadow: 0 0 5px #ff0000; }
  .next-container { background: #1a1a1a; width: 100%; max-width: 320px; padding: 12px; border-radius: 20px; border: 5px solid #ffffff; display: flex; align-items: center; gap: 12px; box-sizing: border-box; }
  .player-box { width: 100%; max-width: 320px; height: 220px; overflow: hidden; position: relative; border-radius: 15px; border: 4px solid #ffffff; background: #000; }
  .player-box iframe { position: absolute; top: -620px; left: 0; width: 100%; height: 1200px; border: none; }
</style>
</head>
<body>
  <div class="main-container">
      <div class="status-bar-red"><div class="status-dot-red"></div><span style="color: #ff0000;">AUTO DJ</span></div>
      <img src="https://i.postimg.cc/Xpdxvkt3/auto-gray.png" style="width: 100px; height: 100px; margin: 0 auto 10px auto; border: 4px solid #ffffff; border-radius: 10px; object-fit: contain;">
      <h1 style="margin: 0; font-size: 22px; color: #ffffff; text-transform: uppercase;">ONE MAN FM</h1>
      <div style="color: #ffffff; font-size: 18px; margin-top: 5px; font-weight: bold;">Non-Stop Hit Music</div>
  </div>
  <div class="next-container">
      <img src="https://i.postimg.cc/nCBTLGgN/my-show-gray.png" style="width: 65px; height: 65px; border-radius: 10px; border: 3px solid #ffffff; object-fit: contain;">
      <div style="color: white; flex: 1; text-align: left;">
          <div style="font-size: 8px; text-transform: uppercase; color: #aaaaaa;">Up Next:</div>
          <div style="font-size: 16px; font-weight: bold;">The Early Morning Shift</div>
          <div style="font-size: 14px; opacity: 0.9;">Leo</div>
      </div>
  </div>
  <div class="player-box"><iframe src="https://onemanfm.radio12345.com/" scrolling="no"></iframe></div>
</body>
</html>
`;

// --- 2. STUDIO HTML ---
const studioHTML = `
<html>
<head><meta name="viewport" content="width=device-width, initial-scale=1.0">
<style>
  body { background: #000; margin: 0; padding: 10px; font-family: sans-serif; }
  .monitor { background: #1a1a1a; border: 4px solid #333; overflow: hidden; border-radius: 10px; margin-bottom: 20px; position: relative; }
  .carousel { display: flex; width: 400%; animation: slide 16s infinite cubic-bezier(0.85, 0, 0.15, 1); }
  .slide { width: 25%; position: relative; }
  .slide img { width: 100%; height: auto; object-fit: contain; }
  .caption { position: absolute; bottom: 10%; left: 5%; background: #ed1c24; color: white; padding: 5px 12px; font-size: 14px; font-weight: bold; text-transform: uppercase; box-shadow: 2px 2px 0px #000; }
  @keyframes slide { 0%, 20% { transform: translateX(0%); } 25%, 45% { transform: translateX(-25%); } 50%, 70% { transform: translateX(-50%); } 75%, 95% { transform: translateX(-75%); } 100% { transform: translateX(0%); } }
</style>
</head>
<body>
  <div class="monitor">
    <div class="carousel">
      <div class="slide"><img src="https://i.ibb.co/vxjkxYkg/deck.jpg"><div class="caption">The Deck</div></div>
      <div class="slide"><img src="https://i.ibb.co/cSj84Rww/desck.jpg"><div class="caption">The Main Desk</div></div>
      <div class="slide"><img src="https://i.ibb.co/4Rj5PGpz/script.jpg"><div class="caption">Current Script</div></div>
      <div class="slide"><img src="https://i.ibb.co/PfdNYmX/stapler-scisors.jpg"><div class="caption">Studio Tools</div></div>
    </div>
  </div>
  <iframe width="100%" height="120" src="https://www.mixcloud.com/widget/iframe/?hide_cover=1&light=0&feed=/one_man_fm/" frameborder="0"></iframe>
</body>
</html>
`;

function PlayerScreen() {
  return (
    <View style={styles.blackContainer}>
      <WebView originWhitelist={['*']} source={{ html: mainLiveHTML }} style={{ flex: 1 }} />
    </View>
  );
}

function StudioScreen() {
  return (
    <View style={styles.blackContainer}>
      <WebView originWhitelist={['*']} source={{ html: studioHTML }} style={{ flex: 1 }} />
    </View>
  );
}

function ChatScreen() {
  return (
    <View style={styles.chatContainer}>
      <Text style={styles.chatHeader}>STUDIO TALK</Text>
      <View style={styles.chatFrame}>
        <WebView
          originWhitelist={['*']}
          source={{ uri: 'https://organizations.minnit.chat/524607848174740/c/Main?embed&nickname=' }}
          style={{ flex: 1 }}
          javaScriptEnabled={true}
          domStorageEnabled={true}
        />
      </View>
      <Text style={styles.chatFooter}>Set a nickname to join the live chat!</Text>
    </View>
  );
}

export default function App() {
  return (
    <NavigationContainer>
      <Tab.Navigator
        screenOptions={{
          tabBarActiveTintColor: '#ff0000',
          tabBarInactiveTintColor: '#fff',
          tabBarStyle: { backgroundColor: '#000', borderTopColor: '#333', height: 60 },
          headerShown: false,
        }}>
        <Tab.Screen name="Live" component={PlayerScreen} options={{ tabBarIcon: ({ color }) => <MaterialIcons name="radio" size={28} color={color} /> }} />
        <Tab.Screen name="Studio" component={StudioScreen} options={{ tabBarIcon: ({ color }) => <MaterialIcons name="visibility" size={28} color={color} /> }} />
        <Tab.Screen name="Talk" component={ChatScreen} options={{ tabBarIcon: ({ color }) => <MaterialIcons name="chat" size={28} color={color} /> }} />
      </Tab.Navigator>
    </NavigationContainer>
  );
}

const styles = StyleSheet.create({
  blackContainer: { flex: 1, backgroundColor: '#000', paddingTop: 40 },
  chatContainer: { flex: 1, backgroundColor: '#000', padding: 20, paddingTop: 50 },
  chatHeader: { color: '#ff0000', fontSize: 22, fontWeight: 'bold', textAlign: 'center', marginBottom: 20, textTransform: 'uppercase' },
  chatFrame: { flex: 1, backgroundColor: '#1a1a1a', borderRadius: 20, overflow: 'hidden', borderWidth: 6, borderColor: '#ffffff' },
  chatFooter: { color: '#666', fontSize: 10, textAlign: 'center', marginTop: 10, fontWeight: 'bold', textTransform: 'uppercase' },
});